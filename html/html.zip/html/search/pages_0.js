var searchData=
[
  ['readme_0',['README',['../md__c_1_2_darbai_22___o_p_22___o_p_23___o_p_2_r_e_a_d_m_e.html',1,'']]]
];
