var searchData=
[
  ['gal_5fbal_0',['gal_bal',['../structduomenys.html#af620763efbfda8d7cba47eaacba0ea04',1,'duomenys']]],
  ['gal_5fbal_5f_1',['gal_bal_',['../class_studentas.html#abe0e5d4d9aab8a28a5bae070a5fc4710',1,'Studentas']]],
  ['gal_5fmed_2',['gal_med',['../structduomenys.html#ad707ffdfff4ce57baab3346b97154057',1,'duomenys']]],
  ['gal_5fmed_5f_3',['gal_med_',['../class_studentas.html#a5fea16104bc45f09342a1485592a3707',1,'Studentas']]],
  ['gal_5fvid_4',['gal_vid',['../structduomenys.html#aea97326b7443d3c52c233169ef5224f3',1,'duomenys']]],
  ['gal_5fvid_5f_5',['gal_vid_',['../class_studentas.html#a8654575dc4377adc46f0b405c0695d17',1,'Studentas']]],
  ['generate_5fnew_5ffile_6',['generate_new_file',['../functions_8cpp.html#a9e9edede9a2c7546eb7884b92dc9abab',1,'generate_new_file():&#160;functions.cpp'],['../functions_8h.html#a9e9edede9a2c7546eb7884b92dc9abab',1,'generate_new_file():&#160;functions.cpp']]],
  ['getegzaminas_7',['getEgzaminas',['../class_studentas.html#abe38c118e8e899b4de681f1d12adceab',1,'Studentas']]],
  ['getgalutinemed_8',['getGalutineMed',['../class_studentas.html#aec68dd4d52e64e10a748648132288cb3',1,'Studentas']]],
  ['getgalutinisbal_9',['getGalutinisBal',['../class_studentas.html#a90fc5e9f1a31cf2d54c859687e4c647e',1,'Studentas']]],
  ['getgalutinisvid_10',['getGalutinisVid',['../class_studentas.html#a50fb3dcf0be0e97934f41641b85ef9e5',1,'Studentas']]],
  ['getnd_11',['getNd',['../class_studentas.html#a61b219cdeb4b697c2fa547f4b1a256c2',1,'Studentas']]],
  ['getndkiekis_12',['getNdKiekis',['../class_studentas.html#aa71badc2b9d3d9d882b007a501a5c179',1,'Studentas']]],
  ['getpavarde_13',['getPavarde',['../class_zmogus.html#af036c7bb67fe710d72aa0428e501cf9e',1,'Zmogus::getPavarde()'],['../class_studentas.html#ae9c8d8f8892d54d529fca28a4ad8268d',1,'Studentas::getPavarde()']]],
  ['getvardas_14',['getVardas',['../class_zmogus.html#ad3bdbae1c0c037255f795221c45533df',1,'Zmogus::getVardas()'],['../class_studentas.html#a3ca6431a4e395c8cea0e47e71a064373',1,'Studentas::getVardas()']]]
];
