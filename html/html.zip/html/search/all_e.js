var searchData=
[
  ['pav_0',['pav',['../structduomenys.html#afc5d2fcfc17c4e1b90fba6add758874b',1,'duomenys']]],
  ['pav_5f_1',['pav_',['../class_zmogus.html#a41f95a6793e83d1584925cc4f7df9b87',1,'Zmogus']]],
  ['perskirstymai_20užpildant_20100000000_20elementų_2',['Kiek kartų įvyksta konteinerių (Vector ir std::vector) atminties perskirstymai užpildant 100000000 elementų.',['../md__c_1_2_darbai_22___o_p_22___o_p_23___o_p_2_r_e_a_d_m_e.html#autotoc_md8',1,'']]],
  ['pointer_3',['pointer',['../class_vector.html#ac261e2da7aee75cdb44477e00de0bd0d',1,'Vector']]],
  ['pop_5fback_4',['pop_back',['../class_vector.html#a96a0a7cacee7603cb7bce3e82c34d0ae',1,'Vector']]],
  ['prasme_20lygiai_20taip_20kaip_20std_3a_3avector_5',['Įsitikinti, ar Vector konteineris veikia (funkcionalumo prasme) lygiai taip, kaip std::vector',['../md__c_1_2_darbai_22___o_p_22___o_p_23___o_p_2_r_e_a_d_m_e.html#autotoc_md0',1,'']]],
  ['push_5fback_6',['push_back',['../class_vector.html#a7cb08d016f15c97741c849cdb83170e1',1,'Vector::push_back(const T &amp;value)'],['../class_vector.html#a23caf2c3ae4086f0d31c4524631385e3',1,'Vector::push_back(T &amp;&amp;value)']]]
];
