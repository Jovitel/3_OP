var searchData=
[
  ['kaip_20std_3a_3avector_0',['Įsitikinti, ar Vector konteineris veikia (funkcionalumo prasme) lygiai taip, kaip std::vector',['../md__c_1_2_darbai_22___o_p_22___o_p_23___o_p_2_r_e_a_d_m_e.html#autotoc_md0',1,'']]],
  ['kartų_20įvyksta_20konteinerių_20vector_20ir_20std_3a_3avector_20atminties_20perskirstymai_20užpildant_20100000000_20elementų_1',['Kiek kartų įvyksta konteinerių (Vector ir std::vector) atminties perskirstymai užpildant 100000000 elementų.',['../md__c_1_2_darbai_22___o_p_22___o_p_23___o_p_2_r_e_a_d_m_e.html#autotoc_md8',1,'']]],
  ['kiek_20kartų_20įvyksta_20konteinerių_20vector_20ir_20std_3a_3avector_20atminties_20perskirstymai_20užpildant_20100000000_20elementų_2',['Kiek kartų įvyksta konteinerių (Vector ir std::vector) atminties perskirstymai užpildant 100000000 elementų.',['../md__c_1_2_darbai_22___o_p_22___o_p_23___o_p_2_r_e_a_d_m_e.html#autotoc_md8',1,'']]],
  ['kodas_3a_3',['Naudotas kodas:',['../md__c_1_2_darbai_22___o_p_22___o_p_23___o_p_2_r_e_a_d_m_e.html#autotoc_md9',1,'']]],
  ['konteinerių_20vector_20ir_20std_3a_3avector_20atminties_20perskirstymai_20užpildant_20100000000_20elementų_4',['Kiek kartų įvyksta konteinerių (Vector ir std::vector) atminties perskirstymai užpildant 100000000 elementų.',['../md__c_1_2_darbai_22___o_p_22___o_p_23___o_p_2_r_e_a_d_m_e.html#autotoc_md8',1,'']]],
  ['konteineris_20veikia_20funkcionalumo_20prasme_20lygiai_20taip_20kaip_20std_3a_3avector_5',['Įsitikinti, ar Vector konteineris veikia (funkcionalumo prasme) lygiai taip, kaip std::vector',['../md__c_1_2_darbai_22___o_p_22___o_p_23___o_p_2_r_e_a_d_m_e.html#autotoc_md0',1,'']]]
];
