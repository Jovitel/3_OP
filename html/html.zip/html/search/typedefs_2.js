var searchData=
[
  ['difference_5ftype_0',['difference_type',['../class_vector.html#a819b4b7de6c5e2e0da894bc5ad44b40d',1,'Vector']]]
];
