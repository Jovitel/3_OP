var searchData=
[
  ['generate_5fnew_5ffile_0',['generate_new_file',['../functions_8cpp.html#a9e9edede9a2c7546eb7884b92dc9abab',1,'generate_new_file():&#160;functions.cpp'],['../functions_8h.html#a9e9edede9a2c7546eb7884b92dc9abab',1,'generate_new_file():&#160;functions.cpp']]],
  ['getegzaminas_1',['getEgzaminas',['../class_studentas.html#abe38c118e8e899b4de681f1d12adceab',1,'Studentas']]],
  ['getgalutinemed_2',['getGalutineMed',['../class_studentas.html#aec68dd4d52e64e10a748648132288cb3',1,'Studentas']]],
  ['getgalutinisbal_3',['getGalutinisBal',['../class_studentas.html#a90fc5e9f1a31cf2d54c859687e4c647e',1,'Studentas']]],
  ['getgalutinisvid_4',['getGalutinisVid',['../class_studentas.html#a50fb3dcf0be0e97934f41641b85ef9e5',1,'Studentas']]],
  ['getnd_5',['getNd',['../class_studentas.html#a61b219cdeb4b697c2fa547f4b1a256c2',1,'Studentas']]],
  ['getndkiekis_6',['getNdKiekis',['../class_studentas.html#aa71badc2b9d3d9d882b007a501a5c179',1,'Studentas']]],
  ['getpavarde_7',['getPavarde',['../class_zmogus.html#af036c7bb67fe710d72aa0428e501cf9e',1,'Zmogus::getPavarde()'],['../class_studentas.html#ae9c8d8f8892d54d529fca28a4ad8268d',1,'Studentas::getPavarde()']]],
  ['getvardas_8',['getVardas',['../class_zmogus.html#ad3bdbae1c0c037255f795221c45533df',1,'Zmogus::getVardas()'],['../class_studentas.html#a3ca6431a4e395c8cea0e47e71a064373',1,'Studentas::getVardas()']]]
];
