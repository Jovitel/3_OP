var searchData=
[
  ['value_5ftype_0',['value_type',['../class_vector.html#ad7f616a3b8800f8b2b4a982cd1886c11',1,'Vector']]],
  ['vard_1',['vard',['../structduomenys.html#af4adf7c4cb28ab1303652dbe34fb6de0',1,'duomenys']]],
  ['vardas_5f_2',['vardas_',['../class_zmogus.html#a80e72cd553492344884a264a72ce33d2',1,'Zmogus']]],
  ['vector_3',['Vector',['../md__c_1_2_darbai_22___o_p_22___o_p_23___o_p_2_r_e_a_d_m_e.html#autotoc_md6',1,'Efektyvumo/spartos analizė std::vector vs Vector'],['../class_vector.html',1,'Vector&lt; T, Allocator &gt;'],['../class_vector.html#ab31d2394e9546728b7b972fa1bf32f53',1,'Vector::Vector()'],['../class_vector.html#a62af81a7700b485b654739e3075c823d',1,'Vector::Vector(size_type count, const T &amp;value=T(), const Allocator &amp;alloc=Allocator())'],['../class_vector.html#ab77d8462fa906703fb763dc452cf02ce',1,'Vector::Vector(std::initializer_list&lt; T &gt; ilist, const Allocator &amp;alloc=Allocator())'],['../class_vector.html#a6c30cb6953c3e82407971f723bfc2ee7',1,'Vector::Vector(const Vector &amp;other)'],['../class_vector.html#acb152d0e8cabec10c1c7d4983dcebffb',1,'Vector::Vector(Vector &amp;&amp;other) noexcept']]],
  ['vector_20ir_20std_3a_3avector_20atminties_20perskirstymai_20užpildant_20100000000_20elementų_4',['Kiek kartų įvyksta konteinerių (Vector ir std::vector) atminties perskirstymai užpildant 100000000 elementų.',['../md__c_1_2_darbai_22___o_p_22___o_p_23___o_p_2_r_e_a_d_m_e.html#autotoc_md8',1,'']]],
  ['vector_20konteineris_20veikia_20funkcionalumo_20prasme_20lygiai_20taip_20kaip_20std_3a_3avector_5',['Įsitikinti, ar Vector konteineris veikia (funkcionalumo prasme) lygiai taip, kaip std::vector',['../md__c_1_2_darbai_22___o_p_22___o_p_23___o_p_2_r_e_a_d_m_e.html#autotoc_md0',1,'']]],
  ['vector_2eh_6',['vector.h',['../vector_8h.html',1,'']]],
  ['veikia_20funkcionalumo_20prasme_20lygiai_20taip_20kaip_20std_3a_3avector_7',['Įsitikinti, ar Vector konteineris veikia (funkcionalumo prasme) lygiai taip, kaip std::vector',['../md__c_1_2_darbai_22___o_p_22___o_p_23___o_p_2_r_e_a_d_m_e.html#autotoc_md0',1,'']]],
  ['vektoriai_2ecpp_8',['vektoriai.cpp',['../vektoriai_8cpp.html',1,'']]],
  ['vs_20vector_9',['Efektyvumo/spartos analizė std::vector vs Vector',['../md__c_1_2_darbai_22___o_p_22___o_p_23___o_p_2_r_e_a_d_m_e.html#autotoc_md6',1,'']]]
];
