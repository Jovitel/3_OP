var searchData=
[
  ['pointer_0',['pointer',['../class_vector.html#ac261e2da7aee75cdb44477e00de0bd0d',1,'Vector']]]
];
