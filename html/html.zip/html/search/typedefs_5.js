var searchData=
[
  ['reference_0',['reference',['../class_vector.html#a6fddac759e5ff7e03257384ae537a5f9',1,'Vector']]],
  ['reverse_5fiterator_1',['reverse_iterator',['../class_vector.html#a9849b4ad17cda28b8df3171e81a3c802',1,'Vector']]]
];
