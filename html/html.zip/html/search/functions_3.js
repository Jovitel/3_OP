var searchData=
[
  ['data_0',['data',['../class_vector.html#a1fcf91de0c080eb7a487dddb3124ed7c',1,'Vector::data() noexcept'],['../class_vector.html#a5eadfc3e4159b0b5b810f87983d67b93',1,'Vector::data() const noexcept']]],
  ['duomenys_1',['duomenys',['../structduomenys.html#af00acbedd054d362a0ea7d2af231b806',1,'duomenys']]]
];
