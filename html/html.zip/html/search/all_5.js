var searchData=
[
  ['efektyvumo_20spartos_20analizė_20std_3a_3avector_20vs_20vector_0',['Efektyvumo/spartos analizė std::vector vs Vector',['../md__c_1_2_darbai_22___o_p_22___o_p_23___o_p_2_r_e_a_d_m_e.html#autotoc_md6',1,'']]],
  ['egzaminas_1',['egzaminas',['../structduomenys.html#a8a50625be60f5720033c7f792e495516',1,'duomenys']]],
  ['egzaminas_5f_2',['egzaminas_',['../class_studentas.html#ab2b6d614a1491c86854d0cd8454a4926',1,'Studentas']]],
  ['elementų_3',['Kiek kartų įvyksta konteinerių (Vector ir std::vector) atminties perskirstymai užpildant 100000000 elementų.',['../md__c_1_2_darbai_22___o_p_22___o_p_23___o_p_2_r_e_a_d_m_e.html#autotoc_md8',1,'']]],
  ['emplace_5fback_4',['emplace_back',['../class_vector.html#a5d19b8e8fd6ded1e2e99045c3962c7e9',1,'Vector']]],
  ['empty_5',['empty',['../class_vector.html#ad5e31c0f82683ece1b5b020c15a8b77b',1,'Vector']]],
  ['end_6',['end',['../class_vector.html#abaaafc8a6696d49ceb4f799d2f78e299',1,'Vector::end() noexcept'],['../class_vector.html#aeebdc6009ad387f9e2f1d37613d98f83',1,'Vector::end() const noexcept']]],
  ['erase_7',['erase',['../class_vector.html#a9475371e34e4ce47ec3359ff25fed6ec',1,'Vector::erase(const_iterator pos)'],['../class_vector.html#a475eb3d5040ead87de3e58e19fe954a3',1,'Vector::erase(const_iterator first, const_iterator last)']]]
];
