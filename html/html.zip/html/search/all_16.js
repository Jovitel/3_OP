var searchData=
[
  ['įsitikinti_20ar_20vector_20konteineris_20veikia_20funkcionalumo_20prasme_20lygiai_20taip_20kaip_20std_3a_3avector_0',['Įsitikinti, ar Vector konteineris veikia (funkcionalumo prasme) lygiai taip, kaip std::vector',['../md__c_1_2_darbai_22___o_p_22___o_p_23___o_p_2_r_e_a_d_m_e.html#autotoc_md0',1,'']]],
  ['įvyksta_20konteinerių_20vector_20ir_20std_3a_3avector_20atminties_20perskirstymai_20užpildant_20100000000_20elementų_1',['Kiek kartų įvyksta konteinerių (Vector ir std::vector) atminties perskirstymai užpildant 100000000 elementų.',['../md__c_1_2_darbai_22___o_p_22___o_p_23___o_p_2_r_e_a_d_m_e.html#autotoc_md8',1,'']]]
];
