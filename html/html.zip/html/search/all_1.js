var searchData=
[
  ['addnd_0',['addnd',['../class_studentas.html#aa0debadd8bb0340b372f90db7d866fcd',1,'Studentas']]],
  ['allocator_5ftype_1',['allocator_type',['../class_vector.html#aab464cb541521d4a0fce87f0a9ba43a3',1,'Vector']]],
  ['analizė_20std_3a_3avector_20vs_20vector_2',['Efektyvumo/spartos analizė std::vector vs Vector',['../md__c_1_2_darbai_22___o_p_22___o_p_23___o_p_2_r_e_a_d_m_e.html#autotoc_md6',1,'']]],
  ['ar_20vector_20konteineris_20veikia_20funkcionalumo_20prasme_20lygiai_20taip_20kaip_20std_3a_3avector_3',['Įsitikinti, ar Vector konteineris veikia (funkcionalumo prasme) lygiai taip, kaip std::vector',['../md__c_1_2_darbai_22___o_p_22___o_p_23___o_p_2_r_e_a_d_m_e.html#autotoc_md0',1,'']]],
  ['assign_4',['assign',['../class_vector.html#addd43241ef82bb05d728d59aed9e0a2c',1,'Vector::assign(size_type count, const T &amp;value)'],['../class_vector.html#a9e96e986dd54712653704af1206dcb11',1,'Vector::assign(std::initializer_list&lt; T &gt; ilist)'],['../class_vector.html#a6b21c817044c259e24cfa380e8f4f8e1',1,'Vector::assign(InputIt first, InputIt last)']]],
  ['at_5',['at',['../class_vector.html#a0949c5f412f6fedaa2a35d35752f0555',1,'Vector::at(size_type pos)'],['../class_vector.html#ad9846a85e41e2534e05616bbbed79f3e',1,'Vector::at(size_type pos) const']]],
  ['atminties_20perskirstymai_20užpildant_20100000000_20elementų_6',['Kiek kartų įvyksta konteinerių (Vector ir std::vector) atminties perskirstymai užpildant 100000000 elementų.',['../md__c_1_2_darbai_22___o_p_22___o_p_23___o_p_2_r_e_a_d_m_e.html#autotoc_md8',1,'']]]
];
