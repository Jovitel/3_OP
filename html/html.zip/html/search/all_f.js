var searchData=
[
  ['rbegin_0',['rbegin',['../class_vector.html#a724ade5c5b5f8f5f8669965125b0e5bd',1,'Vector::rbegin() noexcept'],['../class_vector.html#a3005656f9e4b307d3042dace958177da',1,'Vector::rbegin() const noexcept']]],
  ['read_5fdeque_1',['read_deque',['../functions_8cpp.html#a0261986894c1700072445a9ea2a0b60f',1,'read_deque():&#160;functions.cpp'],['../functions_8h.html#a0261986894c1700072445a9ea2a0b60f',1,'read_deque():&#160;functions.cpp']]],
  ['read_5fdeque_5f2_2',['read_deque_2',['../functions_8cpp.html#a36204f5ae89851aa6732f06c1e134655',1,'read_deque_2():&#160;functions.cpp'],['../functions_8h.html#a36204f5ae89851aa6732f06c1e134655',1,'read_deque_2():&#160;functions.cpp']]],
  ['read_5fdeque_5f3_3',['read_deque_3',['../functions_8cpp.html#ae524de6fd72916f3255cb82d9d89c15f',1,'read_deque_3():&#160;functions.cpp'],['../functions_8h.html#ae524de6fd72916f3255cb82d9d89c15f',1,'read_deque_3():&#160;functions.cpp']]],
  ['read_5flist_4',['read_list',['../functions_8cpp.html#a5d830b5d468cd7416610891b1597fef9',1,'read_list():&#160;functions.cpp'],['../functions_8h.html#a5d830b5d468cd7416610891b1597fef9',1,'read_list():&#160;functions.cpp']]],
  ['read_5flist_5f2_5',['read_list_2',['../functions_8cpp.html#a5c37180904b096c1e84ac65bd86a87c9',1,'read_list_2():&#160;functions.cpp'],['../functions_8h.html#a5c37180904b096c1e84ac65bd86a87c9',1,'read_list_2():&#160;functions.cpp']]],
  ['read_5flist_5f3_6',['read_list_3',['../functions_8cpp.html#aece1ec08c65cda6afb25fcece1dde573',1,'read_list_3():&#160;functions.cpp'],['../functions_8h.html#aece1ec08c65cda6afb25fcece1dde573',1,'read_list_3():&#160;functions.cpp']]],
  ['readme_7',['README',['../md__c_1_2_darbai_22___o_p_22___o_p_23___o_p_2_r_e_a_d_m_e.html',1,'']]],
  ['readme_2emd_8',['README.md',['../_r_e_a_d_m_e_8md.html',1,'']]],
  ['reference_9',['reference',['../class_vector.html#a6fddac759e5ff7e03257384ae537a5f9',1,'Vector']]],
  ['rend_10',['rend',['../class_vector.html#a730043c7d5c7fd7507ec811d99c68a63',1,'Vector::rend() noexcept'],['../class_vector.html#a44277421d823f12b0662bec3349f0e14',1,'Vector::rend() const noexcept']]],
  ['reserve_11',['reserve',['../class_vector.html#aae047b4b6a79dce4dcc3ffc3c39939d2',1,'Vector']]],
  ['resize_12',['resize',['../class_vector.html#a4cd2d6e5693f1001618fa7f078f5a603',1,'Vector::resize(size_type count)'],['../class_vector.html#a789adb6f31915eab5c1e05d34cbff00d',1,'Vector::resize(size_type count, const T &amp;value)']]],
  ['reverse_5fiterator_13',['reverse_iterator',['../class_vector.html#a9849b4ad17cda28b8df3171e81a3c802',1,'Vector']]],
  ['rezultatai_3a_14',['Rezultatai:',['../md__c_1_2_darbai_22___o_p_22___o_p_23___o_p_2_r_e_a_d_m_e.html#autotoc_md7',1,'Rezultatai:'],['../md__c_1_2_darbai_22___o_p_22___o_p_23___o_p_2_r_e_a_d_m_e.html#autotoc_md10',1,'Rezultatai:']]]
];
