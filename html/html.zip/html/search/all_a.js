var searchData=
[
  ['lygiai_20taip_20kaip_20std_3a_3avector_0',['Įsitikinti, ar Vector konteineris veikia (funkcionalumo prasme) lygiai taip, kaip std::vector',['../md__c_1_2_darbai_22___o_p_22___o_p_23___o_p_2_r_e_a_d_m_e.html#autotoc_md0',1,'']]]
];
