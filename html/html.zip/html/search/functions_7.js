var searchData=
[
  ['insert_0',['insert',['../class_vector.html#a58b6689868c3d347a90f6c7c2d60be12',1,'Vector::insert(const_iterator pos, const T &amp;value)'],['../class_vector.html#a0803e8aea61380efb7c0db0ef57eaa0c',1,'Vector::insert(const_iterator pos, size_type count, const T &amp;value)'],['../class_vector.html#a407c7a29c7eab58a2bf6e2bc9d493f01',1,'Vector::insert(const_iterator pos, InputIt first, InputIt last)']]]
];
