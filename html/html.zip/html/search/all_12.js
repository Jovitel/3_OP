var searchData=
[
  ['užpildant_20100000000_20elementų_0',['Kiek kartų įvyksta konteinerių (Vector ir std::vector) atminties perskirstymai užpildant 100000000 elementų.',['../md__c_1_2_darbai_22___o_p_22___o_p_23___o_p_2_r_e_a_d_m_e.html#autotoc_md8',1,'']]],
  ['use_5fexisting_5ffile_1',['use_existing_file',['../functions_8cpp.html#a437d0bd42461db33ca12d6bf46c0542e',1,'use_existing_file():&#160;functions.cpp'],['../functions_8h.html#a437d0bd42461db33ca12d6bf46c0542e',1,'use_existing_file():&#160;functions.cpp']]],
  ['use_5fexisting_5ffile_5f2_2',['use_existing_file_2',['../functions_8cpp.html#a0377922f2deaba2b2c3f92c3b0486e8c',1,'use_existing_file_2():&#160;functions.cpp'],['../functions_8h.html#a0377922f2deaba2b2c3f92c3b0486e8c',1,'use_existing_file_2():&#160;functions.cpp']]],
  ['use_5fexisting_5ffile_5f3_3',['use_existing_file_3',['../functions_8cpp.html#a70532c701c6bdefb1468a0e6b8592da8',1,'use_existing_file_3():&#160;functions.cpp'],['../functions_8h.html#a70532c701c6bdefb1468a0e6b8592da8',1,'use_existing_file_3():&#160;functions.cpp']]]
];
