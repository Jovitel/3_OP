var searchData=
[
  ['pop_5fback_0',['pop_back',['../class_vector.html#a96a0a7cacee7603cb7bce3e82c34d0ae',1,'Vector']]],
  ['push_5fback_1',['push_back',['../class_vector.html#a7cb08d016f15c97741c849cdb83170e1',1,'Vector::push_back(const T &amp;value)'],['../class_vector.html#a23caf2c3ae4086f0d31c4524631385e3',1,'Vector::push_back(T &amp;&amp;value)']]]
];
