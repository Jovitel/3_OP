var searchData=
[
  ['zmogus_0',['Zmogus',['../class_zmogus.html#a905fef3b8ad421a6d023c7ebc295f48e',1,'Zmogus::Zmogus()=default'],['../class_zmogus.html#aa24d52250dd214c31fdd3ce65e8353b0',1,'Zmogus::Zmogus(const std::string &amp;vardas, const std::string &amp;pav)']]]
];
