var searchData=
[
  ['taip_20kaip_20std_3a_3avector_0',['Įsitikinti, ar Vector konteineris veikia (funkcionalumo prasme) lygiai taip, kaip std::vector',['../md__c_1_2_darbai_22___o_p_22___o_p_23___o_p_2_r_e_a_d_m_e.html#autotoc_md0',1,'']]],
  ['teisingas_20output_3a_1',['TEISINGAS OUTPUT:',['../md__c_1_2_darbai_22___o_p_22___o_p_23___o_p_2_r_e_a_d_m_e.html#autotoc_md1',1,'(TEISINGAS) OUTPUT:'],['../md__c_1_2_darbai_22___o_p_22___o_p_23___o_p_2_r_e_a_d_m_e.html#autotoc_md2',1,'(TEISINGAS) OUTPUT:'],['../md__c_1_2_darbai_22___o_p_22___o_p_23___o_p_2_r_e_a_d_m_e.html#autotoc_md3',1,'(TEISINGAS) OUTPUT:'],['../md__c_1_2_darbai_22___o_p_22___o_p_23___o_p_2_r_e_a_d_m_e.html#autotoc_md4',1,'(TEISINGAS) OUTPUT:'],['../md__c_1_2_darbai_22___o_p_22___o_p_23___o_p_2_r_e_a_d_m_e.html#autotoc_md5',1,'(TEISINGAS) OUTPUT:']]],
  ['test_2ecpp_2',['test.cpp',['../test_8cpp.html',1,'']]],
  ['test_5fcase_3',['TEST_CASE',['../test_8cpp.html#a376c881c6ea3bc02f4abac56b3095aaa',1,'test.cpp']]]
];
