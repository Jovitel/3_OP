var searchData=
[
  ['gal_5fbal_0',['gal_bal',['../structduomenys.html#af620763efbfda8d7cba47eaacba0ea04',1,'duomenys']]],
  ['gal_5fbal_5f_1',['gal_bal_',['../class_studentas.html#abe0e5d4d9aab8a28a5bae070a5fc4710',1,'Studentas']]],
  ['gal_5fmed_2',['gal_med',['../structduomenys.html#ad707ffdfff4ce57baab3346b97154057',1,'duomenys']]],
  ['gal_5fmed_5f_3',['gal_med_',['../class_studentas.html#a5fea16104bc45f09342a1485592a3707',1,'Studentas']]],
  ['gal_5fvid_4',['gal_vid',['../structduomenys.html#aea97326b7443d3c52c233169ef5224f3',1,'duomenys']]],
  ['gal_5fvid_5f_5',['gal_vid_',['../class_studentas.html#a8654575dc4377adc46f0b405c0695d17',1,'Studentas']]]
];
