var searchData=
[
  ['max_5fnd_0',['MAX_ND',['../masyvai_8cpp.html#a957fd52692a5335474f1d00ab811946a',1,'MAX_ND:&#160;masyvai.cpp'],['../studentas_8h.html#a957fd52692a5335474f1d00ab811946a',1,'MAX_ND:&#160;studentas.h']]]
];
