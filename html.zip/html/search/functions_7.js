var searchData=
[
  ['setegzaminas_0',['setEgzaminas',['../class_studentas.html#ac7fa2f1df9d544ac1fc050689d1928bc',1,'Studentas']]],
  ['setgalutinemed_1',['setGalutineMed',['../class_studentas.html#a53973275898bb6c945f0b9e54a071bdd',1,'Studentas']]],
  ['setgalutinisbal_2',['setGalutinisBal',['../class_studentas.html#ac3a987db0835e5cfa217fe5a5819918f',1,'Studentas']]],
  ['setgalutinisvid_3',['setGalutinisVid',['../class_studentas.html#ae2191441ce2a553b5317cd48212a3ba2',1,'Studentas']]],
  ['setnd_4',['setNd',['../class_studentas.html#a695bc9626776c845a6d6203401749fa6',1,'Studentas']]],
  ['setndkiekis_5',['setNdKiekis',['../class_studentas.html#a6e05b341e56bde99d84c0886cbea3247',1,'Studentas']]],
  ['setpavarde_6',['setPavarde',['../class_zmogus.html#aa37bf031ae816be4424371202d6eb25b',1,'Zmogus::setPavarde()'],['../class_studentas.html#a4474b649bc6835caac9bfd2d08581ee5',1,'Studentas::setPavarde()']]],
  ['setvardas_7',['setVardas',['../class_zmogus.html#a6011a697c45ce7141c3902e9f57b076d',1,'Zmogus::setVardas()'],['../class_studentas.html#abb31d2c491e65db93bcef14e6cc21cd8',1,'Studentas::setVardas(const std::string &amp;vardas) override']]],
  ['skaiciuotigalutinibal_8',['skaiciuotiGalutiniBal',['../class_studentas.html#a989bd2a2fa2a88643bb5b32bdb882d45',1,'Studentas']]],
  ['studentas_9',['Studentas',['../class_studentas.html#ab459e995e8c9b24cdc9aec5b09a66539',1,'Studentas::Studentas()'],['../class_studentas.html#aa12338d619a3ed46a773ca29ee8ceed4',1,'Studentas::Studentas(const std::string &amp;vardas, const std::string &amp;pav, int egzaminas, const std::vector&lt; int &gt; &amp;nd, int nd_kiekis, double gal_vid, double gal_med)'],['../class_studentas.html#aef0484fe46cf05746f8ffc0d083fcf3e',1,'Studentas::Studentas(const Studentas &amp;other)'],['../class_studentas.html#a732b15e3745fa8e35ff0002cfc4b73b5',1,'Studentas::Studentas(Studentas &amp;&amp;other) noexcept']]]
];
