var searchData=
[
  ['_7estudentas_0',['~Studentas',['../class_studentas.html#a63e449e0f51a0b14340d02ee71b4be23',1,'Studentas']]],
  ['_7ezmogus_1',['~Zmogus',['../class_zmogus.html#ac5615bf607a8f2f1b303ffa04328d24d',1,'Zmogus']]]
];
