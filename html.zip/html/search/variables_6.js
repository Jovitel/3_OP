var searchData=
[
  ['vard_0',['vard',['../structduomenys.html#afc3ce36b22876b154bdb8750d32a4b66',1,'duomenys::vard'],['../structduomenys.html#af4adf7c4cb28ab1303652dbe34fb6de0',1,'duomenys::vard']]]
];
