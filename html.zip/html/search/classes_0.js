var searchData=
[
  ['duomenys_0',['duomenys',['../structduomenys.html',1,'']]]
];
