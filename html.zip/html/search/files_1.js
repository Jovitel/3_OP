var searchData=
[
  ['masyvai_2ecpp_0',['masyvai.cpp',['../masyvai_8cpp.html',1,'']]]
];
