var searchData=
[
  ['egzaminas_0',['egzaminas',['../structduomenys.html#a8a50625be60f5720033c7f792e495516',1,'duomenys']]],
  ['egzaminas_5f_1',['egzaminas_',['../class_studentas.html#ab2b6d614a1491c86854d0cd8454a4926',1,'Studentas']]]
];
