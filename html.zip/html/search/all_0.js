var searchData=
[
  ['addnd_0',['addnd',['../class_studentas.html#aa0debadd8bb0340b372f90db7d866fcd',1,'Studentas']]]
];
